package com.example.Yggdrasil.Activities;

import android.annotation.SuppressLint;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.StrictMode;
import android.view.View;
import android.util.Log;
import android.widget.Toast;

import com.example.Yggdrasil.DataStructures.Plant;
import com.example.Yggdrasil.Utils.CommunicationKeys;
import com.example.Yggdrasil.DataStructures.PlantList;
import com.example.Yggdrasil.R;
import com.example.Yggdrasil.RecyclerViewAdapter;
import com.jakewharton.threetenabp.AndroidThreeTen;

import org.threeten.bp.LocalDate;
import java.sql.*;
import java.util.*;


public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    public Connection con;

    private PlantList plantList;

    ArrayList<Integer> moistVals1 = new ArrayList<Integer>();
    ArrayList<Integer> moistVals2 = new ArrayList<Integer>();
    ArrayList<Integer> moistVals3 = new ArrayList<Integer>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AndroidThreeTen.init(this);

        plantList = PlantList.getInstance(this);
        if (plantList.getSize() == 0) {
            Plant plant1 = new Plant("Tomato", R.drawable.tomatoes, 1, LocalDate.now(), getResources().getDrawable(R.drawable.tomatoes));
            plantList.insertPlant(plant1);
            Plant plant2 = new Plant("lavender", R.drawable.lavender, 1, LocalDate.now(), getResources().getDrawable(R.drawable.lavender));
            plantList.insertPlant(plant2);
            Plant plant3 = new Plant("Bell Pepper", R.drawable.bell_pepper, 1, LocalDate.now(), getResources().getDrawable(R.drawable.bell_pepper));
            plantList.insertPlant(plant3);
        }
        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new RecyclerViewAdapter(this, plantList);
        mRecyclerView.setAdapter(mAdapter);
        getSQLdata();
    }

    public void onRowClicked(int position) {
        Intent intent = new Intent(this, EditPlantActivity.class);
        intent.putExtra(CommunicationKeys.Main_EditPlant_ExtraPlantPosition, position);
        startActivityForResult(intent, CommunicationKeys.Main_EditPlant_RequestCode);
    }

    public void onWateringButtonClicked(int position) {
        int newPos = plantList.waterPlant(position);
        if (newPos != position) {
            mRecyclerView.smoothScrollToPosition(newPos);
            mAdapter.notifyItemMoved(position, newPos); // Indicate possible change of position in list (after sorting)
        }
        mAdapter.notifyItemChanged(newPos);             // Indicate change in DaysRemaining field
    }

    public void onSettingsButtonClicked(View view) {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivityForResult(intent, CommunicationKeys.Main_Settings_RequestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        // Check which request we're responding to
        if (requestCode == CommunicationKeys.Main_NewPlant_RequestCode) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                int pos = data.getIntExtra(CommunicationKeys.NewPlant_Main_PlantPos, 0);
                mRecyclerView.smoothScrollToPosition(pos);
                mAdapter.notifyItemInserted(pos);
            }
        } else if (requestCode == CommunicationKeys.Main_EditPlant_RequestCode) {
            if (resultCode == RESULT_OK) {
                int prevPos = data.getIntExtra(CommunicationKeys.EditPlant_Main_PlantPrevPosition, 0);
                int newPos = data.getIntExtra(CommunicationKeys.EditPlant_Main_PlantNewPosition, 0);
                //mRecyclerView.smoothScrollToPosition(newPos);
                if (newPos != prevPos) {
                    mAdapter.notifyItemMoved(prevPos, newPos);
                }
                mAdapter.notifyItemChanged(newPos);
            } else if (resultCode == CommunicationKeys.EditPlant_Main_ResultDelete) {
                int prevPos = data.getIntExtra(CommunicationKeys.EditPlant_Main_PlantPrevPosition, 0);
                mRecyclerView.smoothScrollToPosition(prevPos);
                mAdapter.notifyItemRemoved(prevPos);
            }
        } else if (requestCode == CommunicationKeys.Main_Settings_RequestCode) {
            if (resultCode == CommunicationKeys.Settings_Main_ResultDeleteAll) {
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    protected String getSQLdata(String... params) {
        String z = "";
        int hoursPerWeek = 168;
        try {
            con = connectionclass();
            if (con == null) {
                z = "Check Internet Access";
            }
            else {
                String query = "select * from SensorData";
                Statement stmt = con.createStatement();
                ResultSet getMaxRow = stmt.executeQuery(query);
                int maxRow= 0;
                int startIndex = 0;

                while (getMaxRow.next())
                    maxRow++;
                getMaxRow.close();

                if (maxRow > hoursPerWeek) {
                    startIndex = maxRow - hoursPerWeek;
                }

                ResultSet rs = stmt.executeQuery(query);

                String moistVal = "";
                int moistureInt;
                int i = 0;
                int arrayIdx = 0;

                while (rs.next()) {
                    if (i >= startIndex) {
                        moistVal = rs.getString("moisture1");
                        moistureInt = Integer.parseInt(moistVal);
                        moistVals1.add(arrayIdx, moistureInt);
                        moistVal = rs.getString("moisture2");
                        moistureInt = Integer.parseInt(moistVal);
                        moistVals2.add(arrayIdx, moistureInt);
                        moistVal = rs.getString("moisture3");
                        moistureInt = Integer.parseInt(moistVal);
                        moistVals3.add(arrayIdx, moistureInt);
                        arrayIdx++;
                    }
                    i++;
                }
                con.close();
                rs.close();
            }
        } catch (Exception ex) {
            z = ex.getMessage();
            Log.d("sql error", z);
        }
        return z;
    }

    @SuppressLint("NewApi")
    public Connection connectionclass() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = "";
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionURL = "jdbc:jtds:sqlserver://cybergarden.database.windows.net:1433;DatabaseName=AppDatabase;" +
                    "user=SeniorDesign@cybergarden;password=Yggdrasil3;encrypt=true;trustServerCertificate=false;" +
                    "hostNameInCertificate=*.database.windows.net;loginTimeout=30";
            connection = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException se) {
            Log.e("error here 1 : ", se.getMessage());
        } catch (ClassNotFoundException e) {
            Log.e("error here 2 : ", e.getMessage());
        } catch (Exception e) {
            Log.e("error here 2 : ", e.getMessage());
        }
        return connection;
    }

}
